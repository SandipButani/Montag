## INSTALLATION

1. `npm install`
2. `npx tailwindcss -i src/styles.css --output public/css/styles.css --watch`
3. `npm run build:tailwind`